var wms_layers = [];


        var lyr_StamenToner_0 = new ol.layer.Tile({
            'title': 'Stamen Toner',
            'type': 'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
    attributions: ' &middot; <a href="http://maps.stamen.com/">Map tiles by Stamen Design, under CC BY 3.0. Data by OpenStreetMap, under ODbL</a>',
                url: 'http://tile.stamen.com/toner/{z}/{x}/{y}.png'
            })
        });
var format_nj_counties_1 = new ol.format.GeoJSON();
var features_nj_counties_1 = format_nj_counties_1.readFeatures(json_nj_counties_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_nj_counties_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_nj_counties_1.addFeatures(features_nj_counties_1);
var lyr_nj_counties_1 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_nj_counties_1, 
                style: style_nj_counties_1,
                interactive: true,
    title: 'nj_counties<br />\
    <img src="styles/legend/nj_counties_1_0.png" /> 66083 - 149265<br />\
    <img src="styles/legend/nj_counties_1_1.png" /> 149265 - 323444<br />\
    <img src="styles/legend/nj_counties_1_2.png" /> 323444 - 501226<br />\
    <img src="styles/legend/nj_counties_1_3.png" /> 501226 - 630380<br />\
    <img src="styles/legend/nj_counties_1_4.png" /> 630380 - 905116<br />'
        });

lyr_StamenToner_0.setVisible(true);lyr_nj_counties_1.setVisible(true);
var layersList = [lyr_StamenToner_0,lyr_nj_counties_1];
lyr_nj_counties_1.set('fieldAliases', {'COUNTY': 'COUNTY', 'COUNTY_LAB': 'COUNTY_LAB', 'CO': 'CO', 'GNIS_NAME': 'GNIS_NAME', 'GNIS': 'GNIS', 'FIPSSTCO': 'FIPSSTCO', 'FIPSCO': 'FIPSCO', 'ACRES': 'ACRES', 'SQ_MILES': 'SQ_MILES', 'POP2010': 'POP2010', 'POP2000': 'POP2000', 'POP1990': 'POP1990', 'POP1980': 'POP1980', 'POPDEN2010': 'POPDEN2010', 'POPDEN2000': 'POPDEN2000', 'POPDEN1990': 'POPDEN1990', 'POPDEN1980': 'POPDEN1980', 'REGION': 'REGION', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_nj_counties_1.set('fieldImages', {'COUNTY': 'TextEdit', 'COUNTY_LAB': 'TextEdit', 'CO': 'TextEdit', 'GNIS_NAME': 'TextEdit', 'GNIS': 'TextEdit', 'FIPSSTCO': 'TextEdit', 'FIPSCO': 'TextEdit', 'ACRES': 'TextEdit', 'SQ_MILES': 'TextEdit', 'POP2010': 'TextEdit', 'POP2000': 'TextEdit', 'POP1990': 'TextEdit', 'POP1980': 'TextEdit', 'POPDEN2010': 'TextEdit', 'POPDEN2000': 'TextEdit', 'POPDEN1990': 'TextEdit', 'POPDEN1980': 'TextEdit', 'REGION': 'TextEdit', 'Shape_Leng': 'TextEdit', 'Shape_Area': 'TextEdit', });
lyr_nj_counties_1.set('fieldLabels', {'COUNTY': 'no label', 'COUNTY_LAB': 'no label', 'CO': 'no label', 'GNIS_NAME': 'no label', 'GNIS': 'no label', 'FIPSSTCO': 'no label', 'FIPSCO': 'no label', 'ACRES': 'no label', 'SQ_MILES': 'no label', 'POP2010': 'no label', 'POP2000': 'no label', 'POP1990': 'no label', 'POP1980': 'no label', 'POPDEN2010': 'no label', 'POPDEN2000': 'no label', 'POPDEN1990': 'no label', 'POPDEN1980': 'no label', 'REGION': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_nj_counties_1.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});